package com.ssafy.model.repository;

public class memberExecption extends Exception {
	public memberExecption(String msg) {
		super(msg);
	}
}
